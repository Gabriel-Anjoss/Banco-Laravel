<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laravel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
    
        .navbar {
            background-color: #007bff !important;
            height: 70px; 
            width: 1300px;  
            margin: 0 auto; 
            display: flex;
            justify-content: center;
            align-items: center;
           
        }

       
        .nav-link[href="Cadastrar.php"] {
            color: white !important;
            font-weight: bold;
        }

     
        .nav-link[href="Consultar.php"] {
            color: gray !important;
            font-weight: bold;
        }

        
        .container {
            max-width: 1000px;
            margin-top: 20px;
            background: #f8f9fa;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }

      
        .btn-cadastrar {
            background-color: #007bff;
            color: white;
            font-weight: bold;
            width: 100%;
        }

        .btn-cadastrar:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg">
   
    <div class="container-fluid">
        <a class="navbar-brand text-white" href="#">Sistema Web</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="Cadastrar.php">Cadastrar</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="Consultar.php">Consultar</a>
                </li>
            </ul>
        </div>
    </div>
</nav>


<div class="container">
<form action="/cadastra-produto" method="POST">
    @csrf  <!-- Adicionando token CSRF para segurança -->
    <div class="mb-3">
        <label for="nome" class="form-label">Nome:</label>
        <input type="text" class="form-control" id="nome" name="nome" placeholder="Digite o nome" required>
    </div>

    <div class="mb-3">
        <label for="valor" class="form-label">Valor:</label>
        <input type="text" class="form-control" id="valor" name="valor" placeholder="Digite o valor" required>
    </div>

    <div class="mb-3">
        <label for="estoque" class="form-label">Quantidade:</label>
        <input type="text" class="form-control" id="estoque" name="estoque" placeholder="Digite a Quantidade" required>
    </div>

    <button type="submit" class="btn btn-cadastrar">Cadastrar</button>
</form>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>



</body>
</html>
